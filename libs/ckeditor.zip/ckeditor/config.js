/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// 配置UI界面的默认颜色
	// config.uiColor = '#AADC6E';
	// 上传图片路径
//    config.filebrowserImageUploadUrl = "/inspection/kb/imageUpload";

	config.language = 'zh-cn';    // 配置语言
//    config.uiColor = '#FFF';         // 背景颜色
	config.width = '100%';         // 宽度
	config.height = '500px';       // 高度
//    config.skin = 'office2003';   //界面v2,kama,office2003  为提高速度,只保留了office2003
	config.image_previewText = ' ';	//去除ckeditor图片上传时文本框中的英文
	config.extraPlugins += (config.extraPlugins ? ',lineheight' : 'lineheight');//行距③（转载）
	config.allowedContent = true; //加这个是为了不让span标签被ckeditor过滤掉,如果加了的话就不需要再加
	config.lineheight_sizes="1em;1.1em;1.2em;1.3em;1.4em;1.5em";

	config.toolbar = 'inspect';
	config.toolbar_inspect =
			[
				['Source'],
				['Copy','Paste','PasteText','PasteFromWord'],
				['Bold','Italic','Underline','Strike','-','Subscript','Superscript'],
				['Image','Table','HorizontalRule','Smiley','SpecialChar'],
				['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','-','Undo','Redo'],
				['Link','Unlink'],
				['NumberedList','BulletedList','TextColor'],
				['Styles','Format','Font','FontSize', 'lineheight']
				,['Footnote','Footnote2']
			];                //配置操作界面上的工具按钮
	config.toolbar_report =
			[
				['Source','-','Preview'],
				['Cut','Copy','Paste','PasteText','PasteFromWord','-','Print', 'SpellChecker', 'Scayt'],
				['Undo','Redo','-','Find','Replace','-','SelectAll','RemoveFormat'],
				['Bold','Italic','Underline','Strike','-','Subscript','Superscript'],
				['NumberedList','BulletedList','-','Outdent','Indent','Blockquote'],
				['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
				['Link','Unlink','Anchor'],
				['Image','Table','HorizontalRule','Smiley','SpecialChar','PageBreak'],
				['Styles','Format', 'Font','FontSize', 'lineheight'],
				['TextColor','BGColor']
			];                //配置操作界面上的工具按钮
	// 字体编辑时的字符集
	config.font_names = '宋体/宋体;华文中宋/华文中宋;仿宋_GB2312/FangSong;黑体/黑体;楷体/楷体_GB2312;隶书/隶书;幼圆/幼圆;'+ config.font_names;
	// 字体大小选项定义
	config.fontSize_sizes = '好大的二号/29px;小二/24px;三号/21px;小三/20px;四号/18px;小四/16px;五号/14px;小五/12px;六号/10px;小六/8px';

};


CKEDITOR.on( 'dialogDefinition', function( ev ){
	var dialogName = ev.data.name;
	var dialogDefinition = ev.data.definition;

	if ( dialogName == 'image' ){
		var infoTab = dialogDefinition.getContents('info');
		var urlField = infoTab.get( 'txtUrl' );
		var widthField = infoTab.get( 'txtWidth');
		widthField['default'] = "440";
	}
});
