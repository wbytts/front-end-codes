(function () {

var MathContext = (function () {
